=====================
z3c.recipe.staticlxml
=====================

:Version: 0.8
:Author:  Stefan Eletzhofer

Abstract
========

A buildout recipe to build a statically linked lxml library.

Usage
=====

Please see the readme in the `src/z3c/recipe/staticlxml` directory.

Changelog
=========

Please see the `CHANGES.txt` file.

Contributors
============

- Reinout van Rees

- Christian Zagrodnick

- Remco Wendt
