WARNING:

The contents of the parts directory are managed
by buildout. Do not make changes here; they will
be lost when you next run buildout.

To control the parts, edit buildout.cfg and
run bin/buildout.

